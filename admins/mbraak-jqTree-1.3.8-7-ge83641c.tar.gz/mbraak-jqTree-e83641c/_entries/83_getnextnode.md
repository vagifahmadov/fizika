---
title: getNextNode
name: node-functions-getnextnode
---

Get the next node in the tree. Does the same as using the *down* key.

Returns a node or null.

{% highlight js %}
var node = node.getNextNode();
{% endhighlight %}
