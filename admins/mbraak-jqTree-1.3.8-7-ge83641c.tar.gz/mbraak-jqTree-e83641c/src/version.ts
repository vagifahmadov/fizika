const version = "1.3.7";

export default version;
