module.exports = require('./webpack.config.base')(false);
